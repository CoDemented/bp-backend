<?
class insert {
    function __construct()
    {
        $query = "INSERT INTO users ('first_name', 'last_name', 'email')";
    }
}




?>